This is a "fill in the blanks" exercise, based around the "Object Management" lectures, and with a little bit of other stuff, such as implementing your own Bullet and Rock objects.

I've done a lot of it for you though, so it shouldn't be *too* hard...

Look at the stuff in ENTITIES.js (the entry point) for your Instructions, and feel free to explore the other parts of the code. You may find clues therein!

To get started, download my template stuff (the live URL is linked below, and the files are also available as "Entities_Exercise.zip" from the Files tab) and work on it locally before uploading your results and submitting a URL to me in the usual fashion when you're done.

https://notendur.hi.is/~pk/308G/Entities_Exercise/